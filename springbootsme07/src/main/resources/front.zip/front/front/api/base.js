﻿const base = {
    url : "http://localhost:8080/springbootsme07/"
}
export default base
